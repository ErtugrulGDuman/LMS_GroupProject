(function(){
  'use strict';

  $('[data-toggle="ion-rangeslider"]').each(function() {
    $(this).ionRangeSlider()
  })

})()